# Install packages if not already installed
if (!require("WGCNA")) install.packages("WGCNA")
if (!require("data.table")) install.packages("data.table")  # for fast file reading


# Set working directory (adjust the path)
setwd("~/Documents/university/بیو/پروژه")

# Read expression data (assuming tab-delimited with row names)
# Adjust header and separator if needed
exprData <- fread("expression_data.tsv", data.table = FALSE)
# If your gene IDs are in the first column and not already rownames:
rownames(exprData) <- exprData[,1]
exprData <- exprData[,-1]
geneVariance <- apply(exprData, 1, var, na.rm = TRUE)
varianceThreshold <- quantile(geneVariance, 0.2) 
filteredExprData <- exprData[geneVariance > varianceThreshold, ]

# Convert data to numeric if not already, and transpose (WGCNA expects samples as rows)
datExpr <- as.data.frame(t(filteredExprData))
# Check for missing values
gsg <- goodSamplesGenes(datExpr, verbose = 3)
if (!gsg$allOK) {
  # Optionally, remove genes/samples with too many missing values:
  datExpr <- datExpr[gsg$goodSamples, gsg$goodGenes]
}
# Choose a set of soft-thresholding powers
powers = c(1:30)
# Call the network topology analysis function
sft <- pickSoftThreshold(datExpr, powerVector = powers, verbose = 5)
# Plot the results to help select a power
par(mfrow = c(1,2))
plot(sft$fitIndices[,1], -sign(sft$fitIndices[,3])*sft$fitIndices[,2],
     xlab = "Soft Threshold (power)", ylab = "Scale Free Topology Model Fit, signed R^2",
     type = "n", main = "Scale independence")
text(sft$fitIndices[,1], -sign(sft$fitIndices[,3])*sft$fitIndices[,2],
     labels = powers, cex = 0.8, col = "blue")
abline(h = 0.89, col = "red")  # you might choose power where R^2 reaches 0.89

plot(sft$fitIndices[,1], sft$fitIndices[,5],
     xlab = "Soft Threshold (power)", ylab = "Mean Connectivity", type = "n",
     main = "Mean connectivity")
text(sft$fitIndices[,1], sft$fitIndices[,5], labels = powers, cex = 0.8, col = "blue")