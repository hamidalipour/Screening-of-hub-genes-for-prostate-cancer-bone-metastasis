library(GEOquery)    
library(limma)       
library(DESeq2)      
library(ggplot2)     
library(pheatmap)    
library(survival)    
library(survminer) 

# Download and Process GSE32269 Dataset
gse <- getGEO("GSE32269", GSEMatrix = TRUE)
expr_data <- exprs(gse[[1]])  # Extract expression data
metadata <- pData(gse[[1]])   # Sample metadata

# Load Hub Genes
hub_genes <- read.csv("Hub_Genes.csv", header = TRUE)$Gene  # Adjust column name if needed

# Identify Primary vs. Metastatic Samples
metadata$SampleType <- ifelse(grepl("primary", metadata$title, ignore.case = TRUE), "Primary", "Metastatic")

# Ensure groups are correctly labeled
table(metadata$SampleType)
metadata$SampleType <- factor(metadata$SampleType, levels = c("Primary", "Metastatic"))


# Differential Expression Analysis
design <- model.matrix(~ metadata$SampleType)
fit <- lmFit(expr_data, design)
fit <- eBayes(fit)
diff_expr <- topTable(fit, adjust.method = "BH", number = Inf)

# Filter Significant Genes (P < 0.05, LogFC > 1)
diff_expr <- diff_expr[diff_expr$adj.P.Val < 0.05 & abs(diff_expr$logFC) > 1, ]

# Validate Hub Genes in DE Results
hub_gene_expr <- expr_data[rownames(expr_data) %in% hub_genes, ]
hub_gene_diff <- diff_expr[rownames(diff_expr) %in% hub_genes, ]

# Convert expression data for plotting
plot_data <- data.frame(
  Gene = rep(rownames(hub_gene_expr), each = ncol(hub_gene_expr)),
  Expression = as.vector(hub_gene_expr),
  SampleType = rep(metadata$SampleType, times = nrow(hub_gene_expr))
)

# Generate Violin Plots
plot_data <- data.frame(
  Gene = rep(rownames(hub_gene_expr), each = ncol(hub_gene_expr)),
  Expression = as.vector(as.matrix(hub_gene_expr)),  # Ensure numeric values
  SampleType = rep(metadata$SampleType, times = nrow(hub_gene_expr))
)
ggplot(plot_data, aes(x = SampleType, y = Expression, fill = SampleType)) +
  geom_violin(trim = FALSE) +
  geom_boxplot(width = 0.1, position = position_dodge(0.9)) +
  facet_wrap(~ Gene, scales = "free_y") +
  theme_minimal() +
  labs(title = "Gene Expression Validation", x = "Sample Type", y = "Expression Level") +
  theme(legend.position = "none")

# Kaplan-Meier Survival Analysis
surv_data <- metadata[, c("survival_time", "survival_status")]
surv_data$survival_status <- as.numeric(surv_data$survival_status)

# Loop through each hub gene
for (gene in hub_genes) {
  high_expr <- expr_data[gene, ] > median(expr_data[gene, ])
  surv_data$group <- ifelse(high_expr, paste("High", gene, "Group"), paste("Low", gene, "Group"))
  
  # Fit Kaplan-Meier Model
  km_fit <- survfit(Surv(survival_time, survival_status) ~ group, data = surv_data)
  
  # Plot Kaplan-Meier Curve
  ggsurvplot(km_fit, data = surv_data, pval = TRUE, conf.int = TRUE, 
             risk.table = TRUE, ggtheme = theme_minimal(),
             title = paste("Kaplan-Meier Survival Curve for", gene))
}
