# Install packages if not already installed
if (!require("WGCNA")) install.packages("WGCNA")
if (!require("data.table")) install.packages("data.table")  # for fast file reading


# Set working directory (adjust the path)
setwd("~/Documents/university/بیو/پروژه")

# Read expression data (assuming tab-delimited with row names)
# Adjust header and separator if needed
exprData <- fread("expression_data.tsv", data.table = FALSE)
rownames(exprData) <- exprData[,1]
exprData <- exprData[,-1]
# Create a trait vector for the 51 samples:
# 0 for primary samples (first 22) and 1 for metastasis samples (next 29)
trait <- c(rep(0, 22), rep(1, 29))

# Optionally, name the vector with the sample names from the filtered expression data:
sample_names <- colnames(exprData)
names(trait) <- sample_names

# Save the trait data to a file (optional)
write.table(trait, file = "trait_data.tsv", sep = "\t", quote = FALSE, row.names = TRUE, col.names = NA)
cat("Trait data saved as 'trait_data.tsv'\n")