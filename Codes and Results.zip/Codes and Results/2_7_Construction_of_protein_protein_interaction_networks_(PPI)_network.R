library(GEOquery)
library(limma)
library(igraph)
library(biomaRt)

# Load dataset from GEO
gse <- getGEO("GSE32269", GSEMatrix = TRUE)
expr_data <- exprs(gse[[1]])  # Extract expression matrix
pheno_data <- pData(gse[[1]]) # Extract sample metadata

# Define sample groups (Adjust based on dataset conditions)
group <- factor(c(rep("Control", 22), rep("Tumor", 33)))

# Create a design matrix for differential expression analysis
design <- model.matrix(~ group)
colnames(design) <- c("Intercept", "Tumor_vs_Control")

# Apply limma for differential expression analysis
fit <- lmFit(expr_data, design)
fit <- eBayes(fit)

# Get DEGs with adjusted p-value < 0.05
deg_results <- topTable(fit, coef="Tumor_vs_Control", adjust="fdr", number=Inf)
deg_results <- deg_results[deg_results$adj.P.Val < 0.05, ]  # Filter significant DEGs

# Save DEGs to CSV for STRING analysis
write.csv(deg_results, "DEGs.csv", row.names=TRUE)

# Connect to Ensembl BioMart
ensembl <- useMart("ensembl", dataset="hsapiens_gene_ensembl")

# Convert Affymetrix probe IDs to gene symbols
probe_ids <- rownames(deg_results)  
gene_mapping <- getBM(attributes = c("affy_hg_u133_plus_2", "hgnc_symbol"),
                      filters = "affy_hg_u133_plus_2",
                      values = probe_ids,
                      mart = ensembl)

# Merge DEG results with gene mapping
deg_results_mapped <- merge(deg_results, gene_mapping, by.x="row.names", by.y="affy_hg_u133_plus_2")
deg_results_mapped <- deg_results_mapped[, c("hgnc_symbol", colnames(deg_results)[-1])]
deg_results_mapped <- deg_results_mapped[deg_results_mapped$hgnc_symbol != "", ]  # Remove missing values

# Save updated DEGs file for STRING
write.csv(deg_results_mapped[, 1], file="~/DEGs_for_STRING.csv", row.names=FALSE, quote=FALSE)

# Read and process the PPI network file
ppi_data <- read.table("~/enrichment_NetworkNeighborAL.tsv", header=TRUE, sep="\t")
g <- graph_from_data_frame(ppi_data, directed=FALSE)

# Save the network graph
write_graph(g, file="PPI_network.graphml", format="graphml")

# Highlight hub genes (replace with your hub gene list)
hub_genes <- c("RACGAP1", "NUSAP1", "ASPM", "CDK1", "AURKA", 
               "CCNA2", "PBK", "DLGAP5", "KIF4A", "NCAPG")

V(g)$color <- ifelse(V(g)$name %in% hub_genes, "red", "blue")

# Save final graph with hub gene annotations
write_graph(g, file="PPI_network_with_hub_genes.graphml", format="graphml")
