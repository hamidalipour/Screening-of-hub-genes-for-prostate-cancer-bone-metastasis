# Load necessary library
library(dplyr)

# Set working directory (adjust the path to your project folder)
setwd("~/Documents/university/بیو/پروژه")

# Read the original data file from GEO2R
data <- read.table("GSE32269.top.table.tsv", header = TRUE, sep = "\t", stringsAsFactors = FALSE)

# Check column names to ensure correct filtering criteria (optional)
print(names(data))

# Filter for DEGs: adjusted P-value < 0.05 and |logFC| ≥ 1
# Adjust the column names below if needed (e.g., "adj.P.Val" and "logFC")
filtered_data <- data %>%
  filter(adj.P.Val < 0.05, abs(logFC) >= 1)

# Optionally, check how many DEGs you have
num_degs <- nrow(filtered_data)
cat("Number of differentially expressed genes:", num_degs, "\n")

# Write the filtered data to a new TSV file
write.table(filtered_data, "DEGs_filtered.tsv", sep = "\t", quote = FALSE, row.names = FALSE)

# Message when done
cat("Filtered data saved as 'DEGs_filtered.tsv'\n")
