library(GEOquery)
library(limma)
library(ggplot2)
library(clusterProfiler)
library(org.Hs.eg.db)
library(DOSE)
library(msigdbr)
library(hgu133plus2.db)
library(fgsea)
library(msigdbr)

# Load dataset
gset <- getGEO("GSE32269", GSEMatrix = TRUE)
data <- exprs(gset[[1]])

# Load metadata
metadata <- pData(gset[[1]])

# Normalize data if needed
data <- log2(data + 1)

# Extract condition correctly
metadata$condition <- as.factor(gsub(".*: ", "", metadata$`characteristics_ch1`))

# Perform differential expression analysis
design <- model.matrix(~ metadata$condition)  # Adjust based on your metadata
fit <- lmFit(data, design)
fit <- eBayes(fit)
results <- topTable(fit, coef=2, number=Inf, sort.by="t")

# Prepare ranked gene list for GSEA
ranked_genes <- results$t
names(ranked_genes) <- rownames(results)  # Gene names must be the rownames

# Get valid gene symbols
valid_symbols <- keys(org.Hs.eg.db, keytype = "SYMBOL")

# Keep only valid symbols
valid_genes <- names(ranked_genes)[names(ranked_genes) %in% valid_symbols]
ranked_genes <- ranked_genes[valid_genes]

gene_mapping <- bitr(names(ranked_genes), 
                     fromType = "SYMBOL", 
                     toType = "ENTREZID", 
                     OrgDb = org.Hs.eg.db)

# Remove any NA values
gene_mapping <- gene_mapping[!is.na(gene_mapping$ENTREZID), ]

# Ensure unique mapping
gene_mapping <- gene_mapping[!duplicated(gene_mapping$SYMBOL), ]

# Map ranked genes to Entrez IDs
ranked_genes <- ranked_genes[gene_mapping$SYMBOL]
names(ranked_genes) <- gene_mapping$ENTREZID
ranked_genes <- sort(ranked_genes, decreasing = TRUE)


# Convert Affymetrix probe IDs to Entrez IDs
gene_mapping <- select(hgu133plus2.db, 
                       keys = rownames(results), 
                       keytype = "PROBEID", 
                       columns = c("ENTREZID"))

# Remove any missing or duplicated mappings
gene_mapping <- gene_mapping[!is.na(gene_mapping$ENTREZID), ]
gene_mapping <- gene_mapping[!duplicated(gene_mapping$PROBEID), ]

# Extract ranking scores (t-values)
ranked_genes <- results$t
names(ranked_genes) <- rownames(results)  # Assign probe IDs first

# Keep only genes that were successfully mapped
ranked_genes <- ranked_genes[gene_mapping$PROBEID]
names(ranked_genes) <- gene_mapping$ENTREZID

# Sort in descending order (required for GSEA)
ranked_genes <- sort(ranked_genes, decreasing = TRUE)

print(length(ranked_genes))  # Should be > 0
print(head(ranked_genes))  # Should show Entrez IDs

# Load MSigDB pathways
msigdb_data <- msigdbr(species = "Homo sapiens", category = "H")

# Convert named vector to data frame
df_ranked <- data.frame(ENTREZID = names(ranked_genes), score = ranked_genes, stringsAsFactors = FALSE)

# Remove duplicate genes by keeping the one with the highest absolute score
df_ranked <- df_ranked[order(abs(df_ranked$score), decreasing = TRUE), ]  # Sort by highest effect size
df_ranked <- df_ranked[!duplicated(df_ranked$ENTREZID), ]  # Keep only the first occurrence

# Convert back to named vector for fgsea
ranked_genes <- df_ranked$score
names(ranked_genes) <- df_ranked$ENTREZID

# Check for duplicates again
sum(duplicated(names(ranked_genes)))  # Should be 0

ranked_genes <- sort(ranked_genes, decreasing = TRUE)

# Load MSigDB gene sets
msigdb_data <- msigdbr(species = "Homo sapiens", category = "H")

# Convert to required format
pathways <- split(msigdb_data$entrez_gene, msigdb_data$gs_name)

# Run fgsea
fgsea_results <- fgsea(
  pathways = pathways,
  stats = ranked_genes,  # Fixed ranked genes
  minSize = 15,
  maxSize = 500,
  nperm = 1000
)

# View results
head(fgsea_results[order(fgsea_results$pval), ])

# Plot results
filtered_results <- subset(fgsea_results, pathway %in% c("HALLMARK_G2M_CHECKPOINT", "HALLMARK_MITOTIC_SPINDLE", "HALLMARK_E2F_TARGETS"))
top_pathways <- fgsea_results[fgsea_results$pathway %in% c("HALLMARK_G2M_CHECKPOINT", "HALLMARK_MITOTIC_SPINDLE", "HALLMARK_E2F_TARGETS"), ]
plotGseaTable(
  pathways = pathways[names(pathways) %in% top_pathways$pathway], 
  stats = ranked_genes, 
  fgseaRes = top_pathways
)


