# Load necessary libraries
library(ggplot2)
library(ggrepel)
library(pheatmap)
library(dplyr)

# Load your data
setwd("~/Documents/university/بیو/پروژه")
data <- read.table("GSE32269.top.table.tsv", header = TRUE, sep = "\t")

# Filter data for DEGs
filtered_data <- data %>%
  filter(adj.P.Val < 0.05, abs(logFC) >= 1)

# Select top 40 genes based on absolute logFC
top_genes <- filtered_data %>%
  arrange(desc(abs(logFC))) %>%
  head(40)

# --- Volcano Plot with correct colors ---
volcano_plot <- ggplot(filtered_data, aes(x = logFC, y = -log10(adj.P.Val))) +
  geom_point(aes(color = ifelse(logFC > 1, "Up-regulated", ifelse(logFC < -1, "Down-regulated", "Not Regulated"))),
             size = 2, alpha = 0.7) +
  scale_color_manual(values = c("Up-regulated" = "red", "Down-regulated" = "blue", "Not Regulated" = "grey")) +
  theme_minimal() +
  geom_text_repel(data = top_genes, aes(label = Gene.symbol), size = 3) +
  labs(title = "Volcano Plot of Differentially Expressed Genes",
       x = "Log2 Fold Change",
       y = "-Log10 Adjusted P-Value",
       color = "Regulation Status") +
  theme(legend.position = "right")
print(volcano_plot)

# --- Heatmap generation ---
# Load your expression data
if (file.exists("expression_data.tsv")){
  expression_data <- read.table("expression_data.tsv", header = TRUE, sep = "\t", row.names = 1)
  
  # Load platform annotation file
  if (file.exists("GPL96-57554.txt")) { # Change this to your actual annotation file
    # Read the annotation file
    platform_data <- read.delim("GPL96-57554.txt", 
                                header = TRUE, 
                                comment.char = "#", 
                                fill = TRUE, 
                                sep = "\t")
    # Check the first few rows to confirm it was read correctly
    head(platform_data)
    
    # Map probe IDs to gene symbols
    gene_symbols <- platform_data[match(rownames(expression_data), platform_data$ID), "Gene.Symbol"]
    
    # Check for NA values and remove them
    #na_genes <- is.na(gene_symbols)
    #if(any(na_genes)){
    #  print(paste("Number of NA gene symbols found", sum(na_genes)))
    #  expression_data <- expression_data[!na_genes, , drop = FALSE]
    #  gene_symbols <- gene_symbols[!na_genes]
    #}
    #rownames(expression_data) <- gene_symbols
    
    
    # Remove duplicate gene symbols
    #duplicate_genes <- duplicated(rownames(expression_data))
    #if(any(duplicate_genes)){
     # print(paste("Number of duplicate gene symbols found:", sum(duplicate_genes)))
    #  expression_data <- expression_data[!duplicate_genes, , drop = FALSE]
    #}
    valid_genes <- !is.na(gene_symbols) & gene_symbols != ""
    if(any(!valid_genes)){
      print(paste("Number of missing or empty gene symbols found:", sum(!valid_genes)))
      expression_data <- expression_data[valid_genes, , drop = FALSE]
      gene_symbols <- gene_symbols[valid_genes]
    }
    
    # Make gene symbols unique
    unique_gene_symbols <- make.unique(gene_symbols)
    rownames(expression_data) <- unique_gene_symbols
    
    
    # --- Debugging: Check gene symbols ---
    print("First 6 gene symbols in top_genes:")
    print(head(top_genes$Gene.symbol))
    print("First 6 row names (gene symbols) in expression_data:")
    print(head(rownames(expression_data)))
    
    # --- Gene symbol matching ---
    matching_genes <- intersect(top_genes$Gene.symbol, rownames(expression_data))
    print(paste("Number of matching genes:", length(matching_genes)))
    print("Matching genes:")
    print(matching_genes)
    
    if (length(matching_genes) > 0) {
      expression_matrix <- expression_data[matching_genes, , drop = FALSE]
      scaled_expression_matrix <- t(scale(t(expression_matrix)))
      
      # Create heatmap
      heatmap_plot <- pheatmap(scaled_expression_matrix,
                               cluster_rows = TRUE,
                               cluster_cols = TRUE,
                               show_rownames = TRUE,
                               show_colnames = TRUE,
                               color = colorRampPalette(c("blue", "white", "red"))(100),
                               main = "Heatmap of Top 40 Differentially Expressed Genes",
                               fontsize_row = 8,
                               fontsize_col = 8
      )
      print(heatmap_plot)
    } else {
      print("No matching genes found for the heatmap. Check gene symbol consistency.")
    }
  } else {
    print("Annotation file not found. Please download it and put it in working directory.")
  }
  
} else {
  print("Expression data file was not found.")
}