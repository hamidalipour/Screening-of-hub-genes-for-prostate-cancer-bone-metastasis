if(!require(BiocManager)) install.packages("BiocManager")
if(!require(affy)) BiocManager::install("affy")
if(!require(limma)) BiocManager::install("limma")
library(affy)
library(limma)

# Set working directory to the folder containing .CEL files
setwd("~/Documents/university/بیو/پروژه/GSE32269_RAW")  # Update this to your local path

# Read and normalize .CEL files
raw_data <- ReadAffy()       # reads all .CEL files from your directory
normalized_data <- rma(raw_data)  # RMA normalization

# Extract expression values
expression_matrix <- exprs(normalized_data)

# Remove the last 4 samples (normal samples)
# Assuming that the columns are in the order described
expression_matrix_filtered <- expression_matrix[, 1:51]

# Save the filtered expression matrix as a .tsv file
write.table(expression_matrix_filtered, 
            file = "expression_data.tsv", 
            sep = "\t", 
            quote = FALSE, 
            row.names = TRUE, 
            col.names = NA)

cat("Filtered expression data saved as 'expression_data.tsv'\n")
