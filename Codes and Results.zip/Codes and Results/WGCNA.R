# Install packages if not already installed
if (!require("WGCNA")) install.packages("WGCNA")
if (!require("data.table")) install.packages("data.table")  # for fast file reading


# Set working directory (adjust the path)
setwd("~/Documents/university/بیو/پروژه")

# Read expression data (assuming tab-delimited with row names)
# Adjust header and separator if needed
exprData <- fread("expression_data.tsv", data.table = FALSE)
# If your gene IDs are in the first column and not already rownames:
rownames(exprData) <- exprData[,1]
exprData <- exprData[,-1]
geneVariance <- apply(exprData, 1, var, na.rm = TRUE)
varianceThreshold <- quantile(geneVariance, 0.3) 
filteredExprData <- exprData[geneVariance > varianceThreshold, ]

# Convert data to numeric if not already, and transpose (WGCNA expects samples as rows)
datExpr <- as.data.frame(t(filteredExprData))
# Check for missing values
gsg <- goodSamplesGenes(datExpr, verbose = 3)
if (!gsg$allOK) {
  # Optionally, remove genes/samples with too many missing values:
  datExpr <- datExpr[gsg$goodSamples, gsg$goodGenes]
}


trait <- read.table("trait_data.tsv", header = TRUE, sep = "\t", row.names = 1)

# Ensure samples match between expression and traits
trait <- trait[colnames(exprData), , drop=FALSE] 


softPower <- 14
# Create adjacency matrix
adjacency <- adjacency(datExpr, power = softPower)

# Turn adjacency matrix into topological overlap matrix (TOM)
TOM <- TOMsimilarity(adjacency)
dissTOM <- 1 - TOM

geneTree <- hclust(as.dist(dissTOM), method = "average")
plot(geneTree, main = "Gene Clustering", xlab = "", sub = "")

# Identify modules using dynamic tree cut
minModuleSize <- 30
dynamicMods <- cutreeDynamic(dendro = geneTree, distM = dissTOM,
                             deepSplit = 2, pamRespectsDendro = FALSE,
                             minClusterSize = minModuleSize)
dynamicColors <- labels2colors(dynamicMods)

# Plot initial modules
plotDendroAndColors(geneTree, dynamicColors, "Dynamic Tree Cut",
                    dendroLabels = FALSE, hang = 0.03, addGuide = TRUE, guideHang = 0.05)



# Merge modules with a merging threshold of 0.25
mergedModules <- mergeCloseModules(datExpr, dynamicColors, cutHeight = 0.25, verbose = 3)
mergedColors <- mergedModules$colors
mergedMEs <- mergedModules$newMEs

# Plot dendrogram with merged modules
plotDendroAndColors(geneTree, mergedColors, "Merged Modules",
                    dendroLabels = FALSE, hang = 0.03, addGuide = TRUE, guideHang = 0.05)

# Calculate module eigengenes
MEList <- moduleEigengenes(datExpr, colors = mergedColors)
MEs <- MEList$eigengenes

# Calculate correlations between module eigengenes and trait
trait <- data.frame(MetastasisStatus = trait)  
moduleTraitCor <- cor(MEs, trait, use = "p")
moduleTraitPvalue <- corPvalueStudent(moduleTraitCor, nrow(datExpr))

# Define color scheme
textMatrix <- paste(signif(moduleTraitCor, 2), "\n(", signif(moduleTraitPvalue, 1), ")", sep = "")
par(mar = c(6, 8.5, 3, 3))

# Plot
labeledHeatmap(Matrix = moduleTraitCor,
               xLabels = colnames(trait),  
               yLabels = names(MEs),
               ySymbols = names(MEs),
               colorLabels = FALSE,
               colors = blueWhiteRed(50),
               textMatrix = textMatrix,
               setStdMargins = FALSE,
               cex.text = 0.9,
               zlim = c(-1, 1))


module <- "cyan"  
moduleGenes <- names(datExpr)[which(mergedColors == sub("ME", "", module))]  
write.table(moduleGenes, paste0("Module_", module, "_genes.tsv"), sep = "\t", quote = FALSE, row.names = TRUE, col.names = NA)





