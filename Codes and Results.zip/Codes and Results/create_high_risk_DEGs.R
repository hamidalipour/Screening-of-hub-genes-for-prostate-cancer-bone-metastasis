library(VennDiagram)

# Read files
cyan_genes <- read.table("Module_cyan_genes.tsv", header = TRUE, sep = "\t", stringsAsFactors = FALSE)
degs <- read.table("DEGs_filtered.tsv", header = TRUE, sep = "\t", stringsAsFactors = FALSE)

# Convert to character and trim whitespace
cyan_genes$x <- trimws(as.character(cyan_genes$x))
degs$ID <- trimws(as.character(degs$ID))

# Find intersection
common_genes <- degs[degs$ID %in% cyan_genes$x, ]

# Save output
write.table(common_genes, "High_Risk_DEGs.tsv", sep = "\t", quote = FALSE, row.names = FALSE)

venn.diagram(
  x = list(
    "Module_cyan_g" = cyan_genes$x,
    "DEGs_filtered" = degs$ID
  ),
  filename = "venn_diagram.png",
  output = TRUE,
  fill = c("cyan", "red"),
  alpha = 0.5,
  cat.col = c("cyan", "red"),
  cat.cex = 1.5
)

# Display the number of common genes
print(paste("Number of common genes:", nrow(common_genes)))
