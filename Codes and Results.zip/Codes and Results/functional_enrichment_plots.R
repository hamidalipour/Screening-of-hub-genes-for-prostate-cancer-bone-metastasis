if (!requireNamespace("BiocManager", quietly = TRUE))
  install.packages("BiocManager")

BiocManager::install("org.Hs.eg.db")

library(clusterProfiler)
library(org.Hs.eg.db)  # Human gene database
library(ggplot2)
library(readr)
library(org.Hs.eg.db)
setwd("~/Documents/university/بیو/پروژه")

# Read the TSV file (assuming first column contains gene symbols)
genes_df <- read.table("High_Risk_DEGs.tsv", header = TRUE, sep = "\t")
# Extract gene symbols (adjust column name if needed)
genes <- genes_df$Gene.symbol  # Replace with the actual column name

# Convert gene symbols to Entrez IDs
gene_entrez <- bitr(genes, fromType="SYMBOL", toType="ENTREZID", OrgDb=org.Hs.eg.db)
# Perform GO enrichment analysis (BP, CC, MF)
ego_bp <- enrichGO(gene = gene_entrez$ENTREZID, OrgDb = org.Hs.eg.db, keyType = "ENTREZID", ont = "BP")
ego_cc <- enrichGO(gene = gene_entrez$ENTREZID, OrgDb = org.Hs.eg.db, keyType = "ENTREZID", ont = "CC")
ego_mf <- enrichGO(gene = gene_entrez$ENTREZID, OrgDb = org.Hs.eg.db, keyType = "ENTREZID", ont = "MF")
# Perform KEGG pathway analysis
kegg <- enrichKEGG(gene = gene_entrez$ENTREZID, organism = "hsa")

# Plot the results
p <- dotplot(ego_bp, showCategory=10) + ggtitle("Biological Process (BP)")
print(p)
p <- dotplot(ego_cc, showCategory=10) + ggtitle("Cellular Component (CC)")
print(p)
p <- dotplot(ego_mf, showCategory=10) + ggtitle("Molecular Function (MF)")
print(p)
p <- dotplot(kegg, showCategory=10) + ggtitle("KEGG Pathways")
print(p)
